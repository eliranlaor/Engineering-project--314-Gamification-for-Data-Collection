package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * this activity handles the google sign in.
 */
public class SignIn extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener{

    public static final String ESTABLISH_SESSION = "/app_server/establish_session/";
    public static final String TOKEN = "token";
    static String tokenId, userName;
    /* the client id of the game, you muse register the app through google developer so you can use
     * google authentication - learn more online*/
    static final String WEB_CLIENT_ID = "973869074920-ues0cr8vkhg6shh08cvkc9o40mtaeg8k.apps.googleusercontent.com";
    private LinearLayout profSec;
    private Button signOut, playGame;
    private SignInButton signIn;
    private TextView name, email;
    private ImageView profPic;
    private GoogleApiClient googleApiClient;
    private static final int REQ_CODE = 9001;
    private HttpSignInPostTask signInPostTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        profSec = (LinearLayout) findViewById(R.id.prof_section);
        signOut = (Button) findViewById(R.id.btn_logout);
        playGame = (Button) findViewById(R.id.go_to_game);
        signIn = (SignInButton) findViewById(R.id.btn_sign_in);
        name = (TextView) findViewById(R.id.name);
        email = (TextView) findViewById(R.id.email);
        profPic = (ImageView) findViewById(R.id.prof_pic);
        signIn.setOnClickListener(this);
        signOut.setOnClickListener(this);
        playGame.setOnClickListener(this);
        profSec.setVisibility(View.GONE);
        playGame.setVisibility(View.GONE);

        // these are google's api variables.
        GoogleSignInOptions googleSignInOptions= new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(WEB_CLIENT_ID).requestEmail().build();
        googleApiClient = new GoogleApiClient.Builder(this).enableAutoManage(this, this).addApi(Auth.GOOGLE_SIGN_IN_API, googleSignInOptions).build();
        GoogleSignInClient googleSignInClient = GoogleSignIn.getClient (this, googleSignInOptions);

        /* if you came here from home activity, it means that you wish to change the user so it a bit different process*/
        String checkFlag = getIntent().getExtras().getString("Activity");
        if(checkFlag.equals("home")){
            signIn.setVisibility(View.GONE);
            signIn();
        }
        else{
            googleSignInClient.silentSignIn ()
                .addOnCompleteListener (this, new OnCompleteListener<GoogleSignInAccount> () {
                    @Override
                    public void onComplete (@NonNull Task<GoogleSignInAccount> task) {
                        try {
                            GoogleSignInAccount account = task.getResult(ApiException.class);
                            tokenId = account.getIdToken();
                            userName = account.getDisplayName();
                            moveToGame();
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                });
        }
    }


    private void signIn(){
        Intent intent = Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
        startActivityForResult(intent, REQ_CODE);
    }


    private void signOut(){
        Auth.GoogleSignInApi.signOut(googleApiClient).setResultCallback(new ResultCallback<Status>() {
            @Override
            public void onResult(@NonNull Status status) {
                updateUI(false);
            }
        });
    }


    private void handleResult(GoogleSignInResult result){
        if(result.isSuccess()){
            // set the user's variable after successful sign in
            GoogleSignInAccount account = result.getSignInAccount();
            String imgUrl;
            if(account.getPhotoUrl() == null){
                profPic.setBackgroundResource(R.drawable.default_user_img);
            }
            else{
                imgUrl = account.getPhotoUrl().toString();
                Glide.with(this).load(imgUrl).into(profPic);
            }
            name.setText(account.getDisplayName());
            userName = account.getDisplayName();
            email.setText(account.getEmail());
            tokenId = account.getIdToken();
            updateUI(true);
        }
        else{
            tokenId = null;
            updateUI(false);

        }
    }


    private void updateUI(boolean isLogIn){
        if(isLogIn){
            profSec.setVisibility(View.VISIBLE);
            playGame.setVisibility(View.VISIBLE);
            signIn.setVisibility(View.GONE);
        }
        else{
            profSec.setVisibility(View.GONE);
            playGame.setVisibility(View.GONE);
            signIn.setVisibility(View.VISIBLE);
        }
    }


    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_sign_in:
                signIn();
                break;
            case R.id.btn_logout:
                signOut();
                break;
            case R.id.go_to_game:
                moveToGame();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ_CODE){
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleResult(result);
        }
    }

    /**
     * moves you to game, after updating the session id.
     */
    private void moveToGame() {
        Map<String, String> postData = new HashMap<>();
        postData.put(TOKEN, tokenId);
        signInPostTask = new HttpSignInPostTask(postData,SignIn.this);
        signInPostTask.execute(getString(R.string.base_url) + ESTABLISH_SESSION);
    }
}
