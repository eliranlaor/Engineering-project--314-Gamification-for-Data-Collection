package com.example.eliranlaor.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * this class represent a Get task. it receives srcActivity and dst class.
 * when performing execute - u should give it your URL addr.
 * it returns data in json object.
 */
public class HttpGetTask extends AsyncTask<String, Void, Void>{
    private Activity srcActivity;
    private Class<?> dstClass;
    private String response;

    /**
     * c-tor
     * @param srcActivity: the activity which we came from.
     * @param dstClass: the activity that we are moving to.
     */
    public HttpGetTask(Activity srcActivity, Class<?> dstClass) {
        this.srcActivity = srcActivity;
        this.dstClass = dstClass;
    }

    /**
     * this method creates the GET request.
     * @param params: this array of strings contains the additional data for the request (such as URL)
     */
    @Override
    protected Void doInBackground(String... params) {

        try {
            URL url = new URL(params[0]);

            // Create the urlConnection
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoInput(true);
            urlConnection.setRequestMethod("GET");
            urlConnection.setRequestProperty("Cookie", HttpSignInPostTask.SESSION_ID_COOKIE);

            int statusCode = urlConnection.getResponseCode();

            if (statusCode ==  200) {

                InputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());

                response = HttpPostTask.convertInputStreamToString(inputStream);

            } else {
                System.err.println("http response was not valid");
            }

        } catch (Exception e) {
            //TODO - handle this exception
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void v) {
        Intent intent = new Intent(srcActivity, dstClass);
        intent.putExtra("response", response);
        srcActivity.startActivity(intent);
        srcActivity.finish();
    }





}