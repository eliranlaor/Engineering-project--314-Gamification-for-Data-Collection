package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Map;

/**
 * this activity is where the user simplify the sentence, according to the category he picked.
 */
public class ContributeGameAndSimplify extends AppCompatActivity {

    static final private String ADD_ANSWER_TO_DB_URL = "/app_server/AddAnswerToDB/";
    private HttpPostTask task;
    private QuestionObject curQuestion;
    private TextView wordText;
    private HttpGetTask getTask;

    private Button changeQuestion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contribute_main_game);


        /*binding vars*/
        final EditText et = (EditText) findViewById(R.id.editText_answer);
        et.setGravity(Gravity.CENTER_HORIZONTAL);
        et.setMaxLines(2);
        TextView questionView = (TextView) findViewById(R.id.questionText);
        TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(questionView, 1, 17, 1,
                TypedValue.COMPLEX_UNIT_DIP);
        Button doneSimplifying = (Button) findViewById(R.id.simplifyDone);
        wordText = (TextView) findViewById(R.id.wordText);
        changeQuestion = (Button) findViewById(R.id.change_word);
        /*binding vars - done*/


        String response = getIntent().getExtras().getString("response");
        response = response.substring(1,response.length()-1);
        try {
            //generate the question instance from the JSON - that arrived from the server.
            curQuestion = new QuestionObject(new JSONObject(response));
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        wordText.setTextSize(17);
        String wordToShow = "   " + curQuestion.getWord() + "   ";
        wordText.setText(wordToShow);
        questionView.setTextSize(20);
        String questionToShow = "  " + curQuestion.getQuestion() + "  ";
        questionView.setText(questionToShow);

        //when done simplifying, go here
        doneSimplifying.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String answer = et.getText().toString();
                curQuestion.setAnswer(answer);
                Map<String, String> postData = QuestionObject.convertQuestionToMap(curQuestion);
                task  = new HttpPostTask(postData,ContributeGameAndSimplify.this);
                task.execute(getString(R.string.base_url) + ADD_ANSWER_TO_DB_URL);
            }
        });


        String temp = curQuestion.getTopic();
        if(temp.equals("SAT vocabulary") || temp.equals("GRE vocabulary")){ temp = temp.substring(0, 3);}
        final String topic = temp;
        // if the user wishes to change the question he received - do this:
        changeQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getTask = new HttpGetTask(ContributeGameAndSimplify.this, ContributeGameAndSimplify.class);
                getTask.execute(getString(R.string.base_url) + ContributeTopicsMenu.QUESTION_BY_TOPIC_URL + "/" + topic);
            }
        });
    }

    public void onBackPressed(){
        Intent intent = new Intent(ContributeGameAndSimplify.this, ContributeTopicsMenu.class);
        startActivity(intent);
        finish();
    }
}
