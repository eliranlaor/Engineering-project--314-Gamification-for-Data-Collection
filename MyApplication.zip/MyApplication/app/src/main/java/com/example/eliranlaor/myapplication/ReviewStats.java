package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.razerdp.widget.animatedpieview.AnimatedPieView;
import com.razerdp.widget.animatedpieview.AnimatedPieViewConfig;
import com.razerdp.widget.animatedpieview.callback.OnPieSelectListener;
import com.razerdp.widget.animatedpieview.data.IPieInfo;
import com.razerdp.widget.animatedpieview.data.SimplePieInfo;

import org.json.JSONObject;

/**
 * this activity is where the statistics of the simplification that the user just reviewed,
 * are presented to the user.
 */
public class ReviewStats extends AppCompatActivity {

    private AnswerObject curAnswer;
    private Button anotherRound, backToTopics;
    private HttpGetTask task;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_stats);
        anotherRound = (Button) findViewById(R.id.retBtn2);
        backToTopics = (Button) findViewById(R.id.retToTopics);

        String response = getIntent().getExtras().getString("response");
        response = response.substring(1,response.length()-1);
        try {
            curAnswer = new AnswerObject(new JSONObject(response));
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        TextView answerView = (TextView) findViewById(R.id.answerText);
        answerView.setTextSize(20);
        String ansToShow = "   " + curAnswer.getAnswer() + "   ";
        answerView.setText(ansToShow);

        // creating the chart
        double pCount = curAnswer.getpCnt();
        double nCount = curAnswer.getnCnt();
        double sum = pCount+nCount;
        int goodPre = (int)((pCount/sum)*100);
        int badPre = (int)((nCount/sum)*100);

        AnimatedPieView animatedPieView = findViewById(R.id.chart);
        AnimatedPieViewConfig config = new AnimatedPieViewConfig();
        config.addData(new SimplePieInfo(badPre, Color.parseColor("#A62C23"), "BAD"));
        config.addData(new SimplePieInfo(goodPre, Color.parseColor("#242E66"), "GOOD"));
        config.duration(1000);
        config.drawText(true);
        config.strokeMode(false);
        config.textSize(52);
        config.selectListener(new OnPieSelectListener<IPieInfo>() {
            @Override
            public void onSelectPie(@NonNull IPieInfo pieInfo, boolean isFloatUp) {
                Toast.makeText(ReviewStats.this, pieInfo.getValue() + "%", Toast.LENGTH_SHORT).show();
            }
        });
        config.startAngle(-180);
        animatedPieView.applyConfig(config);
        animatedPieView.start();

        //if the user wishes to review for another round -do this
        anotherRound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*TODO - should ask user if he really wants to click 'back' because he already lost points getting here*/
                task = new HttpGetTask(ReviewStats.this, ReviewSwipe.class);
                task.execute(getString(R.string.base_url) + ReviewTopicsMenu.REVIEW_BY_TOPIC_URL + "/" + ReviewSwipe.topic);
            }
        });

        //go back to the topics menu
        backToTopics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*TODO - change the target activity to topics main*/
                Intent intent = new Intent(ReviewStats.this, ReviewTopicsMenu.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ReviewStats.this, ReviewTopicsMenu.class);
        startActivity(intent);
        finish();
    }
}
