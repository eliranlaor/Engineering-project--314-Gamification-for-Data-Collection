package com.example.eliranlaor.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;

import static com.example.eliranlaor.myapplication.ContributeTopicsMenu.GET_SCORE_URL;

/**
 * this class represents the leader board of the game.
 */
public class TopContributors extends AppCompatActivity {

    private JSONArray scoreArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_contributers);
        LinearLayout ll = (LinearLayout)findViewById(R.id.linearViewInsideScroll);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT
                , Gravity.CENTER_VERTICAL);
        String response = getIntent().getExtras().getString("response");
        try {
            scoreArray = new JSONArray(response);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        ArrayList<ScoreObject> scoresToPresent =
                ScoreObject.parseJsonArrayIntoArrayList(scoreArray);
        String score, userName, toPresent;
        for (ScoreObject scoreObj : scoresToPresent) {
            TextView textView = new TextView(this);
            textView.setTextSize(20);
            score = String.valueOf(scoreObj.getScore());
            userName = scoreObj.getUserName();
            toPresent = userName + "\'s score is: " + score;
            textView.setText(toPresent);
            textView.setPadding(12, 0 ,12,0);
            textView.setGravity(Gravity.CENTER);
            textView.setBackgroundResource(R.drawable.message_round_corners);
            params.setMargins(0, 0, 15, 15);//220
            params.gravity = Gravity.CENTER_VERTICAL;
            textView.setLayoutParams(params);
            ll.addView(textView);
        }
    }

    /**
     * this method defines the behavior of the back button
     */
    public void onBackPressed(){
        HttpGetTask goToMain = new HttpGetTask(TopContributors.this, HomeScreen.class);
        goToMain.execute(getString(R.string.base_url) + "/" + GET_SCORE_URL);
        finish();
    }

}
