package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;

/**
 * this activity shows the user the top trending answers for the question he just answered
 */
public class ContributeTopTrending extends AppCompatActivity {

    private Button anotherRound, backToTopics;
    private TextView topTrending;
    private HttpGetTask task;
    private JSONArray answersArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contribute_top_trending);
        anotherRound = (Button) findViewById(R.id.retBtn2);
        backToTopics = (Button) findViewById(R.id.retToTopics);
        topTrending = (TextView)  findViewById(R.id.textView_topTrending);

        LinearLayout ll = (LinearLayout)findViewById(R.id.linearViewInsideScroll);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT
                , Gravity.CENTER_VERTICAL);


        // create array list of answers from the json we just got from the server.
        String response = getIntent().getExtras().getString("response");
        try {
            answersArray = new JSONArray(response);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        ArrayList<AnswerObject> answersToPresent =
                AnswerObject.parseJsonArrayIntoArrayList(answersArray);

        // present the answers on the screen
        for (AnswerObject answerObject : answersToPresent) {
            TextView textView = new TextView(this);
            textView.setTextSize(20);
            textView.setText(answerObject.getAnswer());
            textView.setGravity(Gravity.CENTER);
            textView.setBackgroundResource(R.drawable.rectangle);
            textView.setPadding(12, 0, 12, 0);
            params.setMargins(0, 0, 220, 15);
            params.gravity = Gravity.CENTER_VERTICAL;
            textView.setLayoutParams(params);
            ll.addView(textView);
        }

        // if the user wishes to play another round, we need to ask for another question from the
        // server on the same topic
        String temp =  getIntent().getExtras().getString(QuestionObject.TOPIC);
        if(temp.equals("SAT vocabulary") || temp.equals("GRE vocabulary")){ temp = temp.substring(0, 3);}
        final String topic = temp;
        anotherRound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*TODO - should ask user if he really wants to click 'back' because he already lost points getting here*/
                task = new HttpGetTask(ContributeTopTrending.this, ContributeGameAndSimplify.class);
                task.execute(getString(R.string.base_url) + ContributeTopicsMenu.QUESTION_BY_TOPIC_URL + "/" + topic);
            }
        });

        //take the user back to the topics menu
        backToTopics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*TODO - change the target activity to topics main*/
                Intent intent = new Intent(ContributeTopTrending.this, ContributeTopicsMenu.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void onBackPressed(){
        HttpGetTask goToMain = new HttpGetTask(ContributeTopTrending.this, HomeScreen.class);
        goToMain.execute(getString(R.string.base_url) + "/" + ContributeTopicsMenu.GET_SCORE_URL);
    }
}
