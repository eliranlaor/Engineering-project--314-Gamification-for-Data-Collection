package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.os.Bundle;

/**
 * this class extends the TopicMenu class.
 */
public class ContributeTopicsMenu extends TopicMenu{


    static final String QUESTION_BY_TOPIC_URL = "/app_server/getQuestionByTopic";
    static final String GET_SCORE_URL = "app_server/GetScore/";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initializeLayout(R.layout.contribute_main,
                getString(R.string.base_url)+ QUESTION_BY_TOPIC_URL,
                ContributeTopicsMenu.this, ContributeGameAndSimplify.class);
    }

    public void onBackPressed(){
        HttpGetTask goToMain = new HttpGetTask(ContributeTopicsMenu.this, HomeScreen.class);
        goToMain.execute(getString(R.string.base_url) + "/" + GET_SCORE_URL);
    }
}
