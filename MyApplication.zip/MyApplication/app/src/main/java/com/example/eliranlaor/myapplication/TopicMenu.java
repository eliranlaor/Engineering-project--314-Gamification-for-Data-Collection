package com.example.eliranlaor.myapplication;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.constraint.ConstraintSet;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutCompat;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import android.widget.TableRow;
import android.widget.TextView;

/**
 * this class represents the topics menu
 */
public abstract class TopicMenu extends AppCompatActivity {
    private Typeface tf1;
    private TextView title;
    static final private String TITLE_FONT_NAME = "gasalt_black.ttf";
    /* list of topics that the user can play in*/
    static final String[] topicArray = {"SAT", "GRE", "sport", "Law", "Food", "Computers", "Music",
        "Science", "Religion", "Tools", "Movies", "Animals", "Clothing", "Holidays"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /**
     * this function generates the button for each topic.
     * @param layoutResId: the number of the layout that it should modify
     * @param baseURL: the url that need to be set in the onClickListener
     * @param srcActivity: the activity that we came from
     * @param dstClass: where we want to go after the get request.
     */
    protected void initializeLayout(int layoutResId, final String baseURL, final Activity srcActivity, final Class<?> dstClass) {
        setContentView(layoutResId);
        /* defining a font to the Title */
        title = (TextView) findViewById(R.id.categoryTitle);
        tf1 = Typeface.createFromAsset(getAssets() , TopicMenu.TITLE_FONT_NAME);
        title.setTypeface(tf1);
        /* defining a font to the Title  - done*/

        LinearLayout ll = (LinearLayout)findViewById(R.id.topicsLinearView);
        ConstraintSet cs = new ConstraintSet();
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT
                , Gravity.CENTER_VERTICAL);

        ll.setGravity(Gravity.CENTER);

        String curTopic = "";
        // load the topic and set the onClickListener to each button
        for (int i = 0; i < topicArray.length; i++) {
            final Button btn = new Button(this);
            curTopic = topicArray[i];
            if(curTopic.equals("SAT") || curTopic.equals("GRE")){ curTopic += " vocabulary";}
            btn.setId(i);
            btn.setBackgroundColor(Color.TRANSPARENT);
            btn.setBackgroundResource(R.drawable.ripple_btn);
            btn.setGravity(Gravity.CENTER);
            btn.setText(curTopic);
            params.setMargins(250, 0, 0, 30);
            params.gravity = Gravity.CENTER_VERTICAL;

            btn.setLayoutParams(params);//Setting Layout Params

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //ask for a question in this topic from the server
                    HttpGetTask btnTask = new HttpGetTask(srcActivity, dstClass);
                    btnTask.execute(baseURL + "/" + topicArray[btn.getId()]);
                }
            });
            ll.addView(btn);
        }
    }

    public abstract void onBackPressed();
}
