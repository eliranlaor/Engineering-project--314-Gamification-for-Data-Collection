package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

/**
 * this class represents the information and help page of the app.
 */
public class HelpScreen extends AppCompatActivity {

    private Typeface tf1;

    static final private String HELP_FONT_NAME = "atarian_system_italic.ttf";

    String helpText = "HELLO THERE! \nlet's check if you can explain it better!\n\n"
            + "the game idea is to simplify the given sentence.\n"
            + "the game is divided into 2 modes:\n"
            + "Contribute mode and Review mode\n"
            + "In the contribute mode you will receive a word and a short explanation of it, " +
            "and the idea is to simplify the given definition- but you must keep it's logical meaning.\n"
            + "In the review mode you will go over other's simplifications and you have to decide: did their simplification is accurate?\n"
            + "\n let us know if have any ideas or issues:\n"
            + "simplifyme" +" at " +"gmail.com";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_screen);
        tf1 = Typeface.createFromAsset(getAssets() , HelpScreen.HELP_FONT_NAME);
        TextView explaination = (TextView) findViewById(R.id.explanationText);
        explaination.setTextSize(20);
        explaination.setTypeface(tf1);
        explaination.setText(helpText);
    }

    public void onBackPressed(){
        Intent intent = new Intent(HelpScreen.this, HomeScreen.class);
        startActivity(intent);
        finish();
    }
}
