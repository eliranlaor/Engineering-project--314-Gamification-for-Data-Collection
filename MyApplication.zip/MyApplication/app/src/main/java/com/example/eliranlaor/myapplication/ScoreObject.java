package com.example.eliranlaor.myapplication;

import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * this class represents a the score of the user.
 */
public class ScoreObject implements Parcelable {

    private static final String USER_ID = "pk";
    private static final String USER_NAME = "user_name";
    private static final String SCORE = "score";
    private static final String FIELDS = "fields";

    private int userId;
    private String userName;
    private int score;

    /**
     * c-tor
     * @param jsonObject: receives a JSON object, and parse it in order to create a score object.
     */
    public ScoreObject(JSONObject jsonObject){
        try {
//            userId = Integer.parseInt(jsonObject.getJSONObject(FIELDS).getString(USER_ID));
            userName= jsonObject.getJSONObject(FIELDS).getString(USER_NAME);
            score = Integer.parseInt(jsonObject.getJSONObject(FIELDS).getString(SCORE));
        }
        catch (JSONException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * this method parse a Json array into array list of AnswerObject
     */
    static public ArrayList<ScoreObject> parseJsonArrayIntoArrayList(JSONArray jsonArray) {
        ArrayList<ScoreObject> converted = new ArrayList<>();
        ScoreObject temp;
        JSONObject jsonObject;
        try {
            for (int i=0; i<jsonArray.length(); i++) {
                jsonObject = jsonArray.getJSONObject(i);
                temp = new ScoreObject(jsonObject);
                converted.add(temp);
            }
        }
        catch (JSONException ex) {
            ex.printStackTrace();
            return null;
        }
        return converted;
    }

    // Parcelling part
    public ScoreObject(Parcel in){
        String[] data = new String[3];

        in.readStringArray(data);
        // the order needs to be the same as in writeToParcel() method
        this.userId =Integer.parseInt(data[0]);
        this.userName  = data[1];
        this.score = Integer.parseInt(data[2]);
    }


    public static final Creator<ScoreObject> CREATOR = new Creator<ScoreObject>() {
        @Override
        public ScoreObject createFromParcel(Parcel in) {
            return new ScoreObject(in);
        }

        @Override
        public ScoreObject[] newArray(int size) {
            return new ScoreObject[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[] {String.valueOf(this.userId),String.valueOf(this.userName)
                ,String.valueOf(this.score)});
    }

    public int getScore() {
        return score;
    }

    public String getUserName() {
        return userName;
    }
}
