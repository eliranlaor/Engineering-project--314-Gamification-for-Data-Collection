package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.HashMap;
import java.util.Map;

/**
 * this is the first screen of the game.
 */
public class StartScreen extends AppCompatActivity {

    private HttpSignInPostTask signInPostTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_screen);

    }

    /**
     * this function defines the behavior after the screen was tapped.
     * @param view: the function must receives this arg, we didn't use it.
     */
    public void screenTapped(View view) {
        GoogleSignInOptions googleSignInOptions= new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(SignIn.WEB_CLIENT_ID).requestEmail().build();
        GoogleSignInClient googleSignInClient = GoogleSignIn.getClient (this, googleSignInOptions);
        //try to silently sign in with google (means that the user was already logged once)
        googleSignInClient.silentSignIn ()
                .addOnCompleteListener (this, new OnCompleteListener<GoogleSignInAccount>() {
                    @Override
                    public void onComplete (@NonNull Task<GoogleSignInAccount> task) {
                        try {
                            GoogleSignInAccount account = task.getResult(ApiException.class);
                            SignIn.tokenId = account.getIdToken();
                            SignIn.userName = account.getDisplayName();
                            moveToGame();
                        }
                        // if the silent sign in wasn't end successfully, try to log in via the SignIn activity.
                        catch (ApiException apiException){
                            int stCode = apiException.getStatusCode();
                            if(stCode == CommonStatusCodes.SIGN_IN_REQUIRED){
                                Intent intent = new Intent(StartScreen.this, SignIn.class);
                                intent.putExtra("Activity", "splash");
                                startActivity(intent);
                                finish();
                            }
                            else{
                                apiException.printStackTrace();
                            }
                        }
                    }
                });
    }

    /**
     * this function moves you after getting the session_id from the server.
     */
    private void moveToGame() {
        Map<String, String> postData = new HashMap<>();
        postData.put(SignIn.TOKEN, SignIn.tokenId);
        signInPostTask = new HttpSignInPostTask(postData,StartScreen.this);
        signInPostTask.execute(getString(R.string.base_url) + SignIn.ESTABLISH_SESSION);
    }

}
