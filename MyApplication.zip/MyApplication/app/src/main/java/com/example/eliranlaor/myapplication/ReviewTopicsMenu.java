package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.os.Bundle;

/**
 * this activity is the topic's menu for the review path
 */
public class ReviewTopicsMenu extends TopicMenu {


    static final String REVIEW_BY_TOPIC_URL = "/app_server/getReviewByTopic";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initializeLayout(R.layout.review_main,
                getString(R.string.base_url) + REVIEW_BY_TOPIC_URL, ReviewTopicsMenu.this,
                ReviewSwipe.class);
    }


    public void onBackPressed(){
        HttpGetTask goToMain = new HttpGetTask(ReviewTopicsMenu.this, HomeScreen.class);
        goToMain.execute(getString(R.string.base_url) + "/" + ContributeTopicsMenu.GET_SCORE_URL);
    }
}
