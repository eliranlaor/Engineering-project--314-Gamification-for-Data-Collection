package com.example.eliranlaor.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import java.util.Map;


/**
 * this class represents a POST request to the server
 */
public class HttpPostTask extends AsyncTask<String, Void, Void>{
    private Activity activity;
    // This is the JSON body of the post
    JSONObject postData;
    // This the response from server
    private String response;
    
    private String questionTopic;

    /**
     * c-tor
     * @param postData: the post's data.
     * @param activity: the activity the we came from.
     */
    public HttpPostTask(Map<String, String> postData, Activity activity) {
        this.activity = activity;
        if (postData != null) {
            this.postData = new JSONObject(postData);
            questionTopic = postData.get(QuestionObject.TOPIC);
        }
    }

    // This is a function that we are overriding from AsyncTask.
    // It takes Strings as parameters because that is what we defined for the parameters of our async task
    @Override
    protected Void doInBackground(String... params) {

        try {
            // This is getting the url from the string we passed in
            URL url = new URL(params[0]);

            // Create the urlConnection
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Cookie", HttpSignInPostTask.SESSION_ID_COOKIE);

            // Send the post body - in our case the user answer.
            if (this.postData != null) {
                OutputStreamWriter writer = new OutputStreamWriter(urlConnection.getOutputStream());
                writer.write(postData.toString());
                writer.flush();
            }

            int statusCode = urlConnection.getResponseCode();

            if (statusCode ==  200) {
                InputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                response = HttpPostTask.convertInputStreamToString(inputStream);
            } else {
                System.err.println("http response was not valid");
                // Status code is not 200
                // Do something to handle the error
            }

        } catch (Exception e) {
            //TODO - handle this exception
            e.printStackTrace();
        }
        return null;
    }

    @Override
    /*
     * perform this after you done getting the answer from the server.
     */
    protected void onPostExecute(Void v) {
        Intent intent = new Intent(activity, ContributeTopTrending.class);
        intent.putExtra("response", response);
        intent.putExtra(QuestionObject.TOPIC, questionTopic);
        activity.startActivity(intent);
        activity.finish();
    }


    /**
     * this method convert the InputStream into a string.
     * @param is: input stream
     * @return: the string that was read from the stream
     */
    static String convertInputStreamToString(InputStream is) {
        String line = "";
        StringBuilder total = new StringBuilder();
        BufferedReader rd = new BufferedReader(new InputStreamReader(is));
        try {
            while ((line = rd.readLine()) != null) {
                total.append(line);
            }
        } catch (Exception e) {
            //TODO - handle this exception
            e.printStackTrace();
        }
        return total.toString();
    }



}