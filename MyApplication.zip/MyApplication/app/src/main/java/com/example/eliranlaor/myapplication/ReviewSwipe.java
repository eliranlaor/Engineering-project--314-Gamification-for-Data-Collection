package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * this activity is where the user review other's simplifications.
 */
public class ReviewSwipe extends AppCompatActivity {

    static final String UPDATE_ANSWER_URL = "/app_server/UpdateAnswerCount";

    private GestureDetector gestureDetector;
    View.OnTouchListener gestureListener;
    private String response;
    private JSONArray jsonArray;
    private QuestionObject curQuestion;
    private AnswerObject curAnswer;
    private HttpGetTask task;
    static String topic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_swipe);

        response = getIntent().getExtras().getString("response");
        try {
            jsonArray = new JSONArray(response);
            curQuestion = new QuestionObject(jsonArray.getJSONObject(0));
            topic = curQuestion.getTopic();
            if(topic.equals("SAT vocabulary") || topic.equals("GRE vocabulary")){ topic = topic.substring(0, 3);}
            JSONArray answersJSONArray = makeAnswerArray();
            ArrayList<AnswerObject> answersToPresent =
                    AnswerObject.parseJsonArrayIntoArrayList(answersJSONArray);
            curAnswer = answersToPresent.get(0);
            TextView questionView = (TextView) findViewById(R.id.questionText);
            TextView answerView = (TextView) findViewById(R.id.answerText);
            questionView.setTextSize(20);
            questionView.setText(curQuestion.getQuestion());
            answerView.setTextSize(20);
            answerView.setText(curAnswer.getAnswer());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        //swipes buttons
        Button choose = (Button) findViewById(R.id.MidBtn);
        gestureDetector = new GestureDetector(new SwipeGestureDetector());
        gestureListener = new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return gestureDetector.onTouchEvent(event);
            }
        };
        choose.setOnTouchListener(gestureListener);
    }

    private void onLeftSwipe() {
        Toast t = Toast.makeText(ReviewSwipe.this, "Left swipe", Toast.LENGTH_LONG);
        t.show();
        task = new HttpGetTask(ReviewSwipe.this, ReviewStats.class);
        task.execute(getString(R.string.base_url) + ReviewSwipe.UPDATE_ANSWER_URL + "/" + curAnswer.getId() + "/-");
    }

    private void onRightSwipe() {
        Toast t = Toast.makeText(ReviewSwipe.this, "Right swipe", Toast.LENGTH_LONG);
        t.show();
        task = new HttpGetTask(ReviewSwipe.this, ReviewStats.class);
        task.execute(getString(R.string.base_url) + ReviewSwipe.UPDATE_ANSWER_URL + "/" + curAnswer.getId() + "/+");
    }

    /* this class implements the onFLing method, which processing the swipe of the user*/
    private class SwipeGestureDetector extends GestureDetector.SimpleOnGestureListener {
        private static final int SWIPE_MIN_DISTANCE = 50;
        private static final int SWIPE_MAX_OFF_PATH = 200;
        private static final int SWIPE_THRESHOLD_VELOCITY = 200;

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
                               float velocityY) {
            try {
                float diffAbs = Math.abs(e1.getY() - e2.getY());
                float diff = e1.getX() - e2.getX();

                if (diffAbs > SWIPE_MAX_OFF_PATH)
                    return false;

                // Left swipe
                if (diff > SWIPE_MIN_DISTANCE
                        && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                    ReviewSwipe.this.onLeftSwipe();
                }
                // Right swipe
                else if (-diff > SWIPE_MIN_DISTANCE
                        && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
                    ReviewSwipe.this.onRightSwipe();
                }
            } catch (Exception e) {
                //TODO handel ex
            }
            return false;
        }

    }

    private JSONArray makeAnswerArray(){
        try {
            JSONArray list = new JSONArray();
            int len = jsonArray.length();
            if (jsonArray != null) {
                for (int i = 0; i < len; i++) {
                    //Excluding the item at position
                    if (i != 0) {
                        list.put(jsonArray.get(i));
                    }
                }
            }
            return list;
        }
        catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ReviewSwipe.this, ReviewTopicsMenu.class);
        startActivity(intent);
        finish();
    }
}
