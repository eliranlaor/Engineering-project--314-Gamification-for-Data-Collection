package com.example.eliranlaor.myapplication;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import org.json.JSONObject;

/**
 * this class represents the Home screen of the game. after signing in, the user will get here
 */
public class HomeScreen extends AppCompatActivity {

    static final String topContribUrl = "app_server/GetTopScore/";
    public static String score;
    private TextView scoreText;
    private Button changeUser, topContrib;
    private Typeface tf1;

    static final private String SCORE_FONT_NAME = "atarian_system_italic.ttf";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*Binding XML to class*/
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*Binding XML to class - done*/

        changeUser = (Button) findViewById(R.id.cngUsr);
        scoreText = (TextView) findViewById(R.id.score_text);
        tf1 = Typeface.createFromAsset(getAssets() , HomeScreen.SCORE_FONT_NAME);

        // update the score before present it to the user.
        if(getIntent().getExtras() != null){
            String response = getIntent().getExtras().getString("response");
            response = response.substring(1,response.length()-1);
            try {
                JSONObject jsonObject = new JSONObject(response);
                score = jsonObject.getJSONObject(QuestionObject.FIELDS).getString("score");
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }

        String msg = "Hello " + SignIn.userName + "! \n Your score is: " + score;
        scoreText.setText(msg);
        scoreText.setTypeface(tf1);
        scoreText.setTextSize(24);


        /*switching to contribute screen*/
        Button contributeBtn = (Button) findViewById(R.id.ctbBtn);
        contributeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreen.this, ContributeTopicsMenu.class);
                startActivity(intent);
                finish();
            }
        });
        /*switching to contribute screen - Done*/

        /*switching to review screen*/
        Button reviewBtn = (Button) findViewById(R.id.revBtn);
        reviewBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreen.this, ReviewTopicsMenu.class);
                startActivity(intent);
                finish();
            }
        });
        /*switching to review screen - done*/


        /*switching to help screen*/
        Button helpBtn = (Button) findViewById(R.id.helpBtn);
        helpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreen.this, HelpScreen.class);
                startActivity(intent);
                finish();
            }
        });
        /*switching to help screen - done*/


        /*switching to top contributors screen*/
        topContrib = (Button) findViewById(R.id.top_contrib);
        topContrib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ask the server to send us the top 10 contributors
                HttpGetTask btnTask = new HttpGetTask(HomeScreen.this, TopContributors.class);
                btnTask.execute(getString(R.string.base_url) + "/" + topContribUrl);
            }
        });
        /*switching to top contributors screen - done*/

        /*switching to top switch user screen*/
        changeUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreen.this, SignIn.class);
                intent.putExtra("Activity", "home");
                startActivity(intent);
                finish();
            }
        });
        /*switching to top switch user screen - done*/

    }
}
