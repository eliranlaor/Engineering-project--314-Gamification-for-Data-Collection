package com.example.eliranlaor.myapplication;

import android.app.Activity;
import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * this class represents answer object of the user. the answers of the user are stored in these items
 */
public class AnswerObject extends Activity implements Parcelable {

    private static final String PK = "pk";
    private static final String QUESTION_ID = "question_id";
    private static final String POS_CNT = "positive_count";
    private static final String NEG_CNT = "negative_count";
    private static final String ANSWER = "answer";
    private static final String FIELDS = "fields";


    private int id;
    private int question_id;
    private String answer;
    private int pCnt;
    private int nCnt;


    /**
     * copy c-tor from JSON object
     */
    public AnswerObject(JSONObject jsonObject) {
        try {
            id = Integer.parseInt(jsonObject.getString(PK));
            question_id = Integer.parseInt(jsonObject.getJSONObject(FIELDS).getString(QUESTION_ID));
            pCnt= Integer.parseInt(jsonObject.getJSONObject(FIELDS).getString(POS_CNT));
            nCnt= Integer.parseInt(jsonObject.getJSONObject(FIELDS).getString(NEG_CNT));
            answer = jsonObject.getJSONObject(FIELDS).getString(ANSWER);
        }
        catch (JSONException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * this method parse a Json array into array list of AnswerObject
     */
    static public ArrayList<AnswerObject> parseJsonArrayIntoArrayList(JSONArray jsonArray) {
        ArrayList<AnswerObject> converted = new ArrayList<>();
        AnswerObject temp;
        JSONObject jsonObject;
        try {
            for (int i=0; i<jsonArray.length(); i++) {
                jsonObject = jsonArray.getJSONObject(i);
                temp = new AnswerObject(jsonObject);
                converted.add(temp);
            }

        }
        catch (JSONException ex) {
            ex.printStackTrace();
            return null;
        }
        return converted;
    }

    // Parcelling part
    public AnswerObject(Parcel in){
        String[] data = new String[5];

        in.readStringArray(data);
        // the order needs to be the same as in writeToParcel() method
        this.id =Integer.parseInt(data[0]);
        this.question_id  = Integer.parseInt(data[1]);
        this.answer = data[2];
        this.pCnt = Integer.parseInt(data[3]);
        this.nCnt  = Integer.parseInt(data[4]);
    }

    public int describeContents(){
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[] {String.valueOf(this.id),String.valueOf(this.question_id)
                ,this.answer, String.valueOf(this.pCnt), String.valueOf(this.nCnt)});
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public AnswerObject createFromParcel(Parcel in) {
            return new AnswerObject(in);
        }

        public AnswerObject[] newArray(int size) {
            return new AnswerObject[size];
        }
    };

    public String getAnswer() {
        return this.answer;
    }

    public int getId() { return id; }

    public int getnCnt() { return nCnt; }

    public int getpCnt() { return pCnt; }

}
