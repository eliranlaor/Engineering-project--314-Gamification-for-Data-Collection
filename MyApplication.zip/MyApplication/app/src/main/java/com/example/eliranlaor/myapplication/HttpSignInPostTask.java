package com.example.eliranlaor.myapplication;


import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import java.util.Map;

public class HttpSignInPostTask extends AsyncTask<String, Void, Void> {

    /** this is the unique session id of the user*/
    static String SESSION_ID_COOKIE;
    // This is the JSON body of the post
    JSONObject postData;
    // This the response from server
    private String response;
    private Activity activity;

    /**
     * c-tor
     * @param postData: the post's data.
     * @param activity: the activity the we came from.
     */
    public HttpSignInPostTask(Map<String, String> postData, Activity activity) {
        this.activity = activity;
        if (postData != null) {
            this.postData = new JSONObject(postData);
        }
    }

    // This is a function that we are overriding from AsyncTask.
    // It takes Strings as parameters because that is what we defined for the parameters of our async task
    @Override
    protected Void doInBackground(String... params) {

        try {
            // This is getting the url from the string we passed in
            URL url = new URL(params[0]);
            // Create the urlConnection
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoInput(true);
            urlConnection.setDoOutput(true);
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestMethod("POST");

            // Send the post body
            if (this.postData != null) {
                OutputStreamWriter writer = new OutputStreamWriter(urlConnection.getOutputStream());
                writer.write(postData.toString());
                writer.flush();
            }
            int statusCode = urlConnection.getResponseCode();

            if (statusCode == 200) {
                InputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                response = HttpPostTask.convertInputStreamToString(inputStream);
                String headerName = null;
                //here we are parsing the cookie the we got from the server and find the session id
                for (int i =0; (headerName = urlConnection.getHeaderFieldKey(i)) != null; i++)
                {
                    if(headerName.equals("Set-Cookie"))
                    {
                        SESSION_ID_COOKIE = urlConnection.getHeaderField(i);
                    }
                }
            } else {
                System.err.println("http response was not valid");
                // Status code is not 200
                // Do something to handle the error
            }

        } catch (Exception e) {
            //TODO - handle this exception
            e.printStackTrace();
        }
        return null;
    }

    @Override
    /*
     * this function moves to HomeScreen after the async task is over.
     */
    protected void onPostExecute(Void v) {
        Intent intent = new Intent(activity, HomeScreen.class);
        intent.putExtra("response", response);
        activity.startActivity(intent);
    }

}