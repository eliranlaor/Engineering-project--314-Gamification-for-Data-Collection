import numpy as np
import pandas as pd
from matplotlib.pyplot import *
from sentencesVerif import *

raw_data = pd.read_csv("/cs/engproj/314/proj2/app_backend/our_db.csv", sep='\$', engine='python')


def estimate_y(test_data):
    """
    helper function for the plot_err function
    :param test_data:
    :return:
    """
    y = []
    for index, row in test_data.iterrows():
        question = row['question']
        answer = row['answer']
        res = calc_distance(question, answer)
        print(res)
        y.append(res)
    return y


def plot_err():
    """
    this function plots the error of the GateKeeper
    :return: nothing
    """
    test_data = raw_data.drop(['tag'], axis=1)  # we need to estimate the tag with WMD
    data_y = raw_data[['tag']]
    y_hat = estimate_y(test_data)
    # y_hat = np.random.uniform(low=0.5, high=7, size=(len(data_y),))
    np_y = data_y.values
    threshold = np.arange(0.0, 7.0, 0.01)
    error_array = []
    FNR = []
    ratio = []
    mistakes_count = 0
    for index, t in enumerate(threshold):
        error_array.append(0)
        FNR.append(0)
        for i in range(len(data_y)):
            cur_val = y_hat[i]
            if cur_val <= t:
                cur_val = 1
            else:
                cur_val = 0
            is_good = 1 if cur_val == np_y[i][0] else 0
            if is_good == 0:
                mistakes_count += 1
                if cur_val == 0:
                    FNR[index] += 1
            error_array[index] += is_good
        error_array[index] = error_array[index] / len(data_y)
        FNR[index] = FNR[index] / mistakes_count
        ratio.append(error_array[index] / FNR[index])
        mistakes_count = 0
        print("t was " + str(t) + "  FNR was " + str(FNR[index]))
    plot(threshold, error_array)
    plot(threshold, FNR)
    plot(threshold, ratio)
    title("Accuracy of spam detection as function of Threshold")
    xlabel("Threshold")
    ylabel("Accuracy")
    legend(['accuracy rate', 'FNR rate', 'ratio'])
    grid(True)
    show()


init_word2vec()
plot_err()
